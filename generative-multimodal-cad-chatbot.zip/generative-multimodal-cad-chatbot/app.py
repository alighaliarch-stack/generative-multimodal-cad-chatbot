import os
import uuid
import datetime

from flask import Flask, request, jsonify, render_template, send_from_directory
from dotenv import load_dotenv

import google.generativeai as genai
from elevenlabs.client import ElevenLabs
from elevenlabs import save

# --------------------------------------------------
# LOAD ENV
# --------------------------------------------------
load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
ELEVEN_API_KEY = os.getenv("ELEVEN_API_KEY")

if not GOOGLE_API_KEY:
    raise RuntimeError("GOOGLE_API_KEY not found")
if not ELEVEN_API_KEY:
    raise RuntimeError("ELEVEN_API_KEY not found")

# --------------------------------------------------
# CONFIG
# --------------------------------------------------
MAX_INPUT_CHARS = 2000
MAX_TTS_CHARS = 400

VOICE_ID = "mkpDAsPoFVoiBtht9Cht"

SYSTEM_PROMPT = """
You are an architectural design assistant for conceptual building planning.

RULES:
- Do NOT generate OpenSCAD code.
- Do NOT use programming or scripting language.
- Respond ONLY with clear, human-readable architectural instructions.
- Use short bullet points or numbered steps.
- Focus on rooms, floors, circulation, and spatial relationships.
- Keep responses concise and practical.

Assume the output will later be converted into CAD by another system.
"""

# --------------------------------------------------
# CLIENTS
# --------------------------------------------------
genai.configure(api_key=GOOGLE_API_KEY)
gemini_model = genai.GenerativeModel("gemini-2.5-flash")

eleven_client = ElevenLabs(api_key=ELEVEN_API_KEY)

# --------------------------------------------------
# FLASK
# --------------------------------------------------
app = Flask(__name__)

# --------------------------------------------------
# HOME
# --------------------------------------------------
@app.route("/")
def home():
    return render_template("index.html")

# --------------------------------------------------
# CHAT (TEXT + OPTIONAL VOICE)
# --------------------------------------------------
@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.form.get("user_input", "").strip()

    if not user_input:
        return jsonify({"response": "Please enter a message.", "audio": None})

    user_input = user_input[:MAX_INPUT_CHARS]

    try:
        prompt = f"{SYSTEM_PROMPT}\n\nUser request:\n{user_input}"

        response = gemini_model.generate_content(prompt)
        reply = response.text.strip()

        audio_path = None
        if len(reply) <= MAX_TTS_CHARS:
            audio_path = speak_text(reply)

        return jsonify({
            "response": reply,
            "audio": audio_path
        })

    except Exception as e:
        return jsonify({
            "response": f"Gemini error: {str(e)}",
            "audio": None
        })

# --------------------------------------------------
# ELEVENLABS TTS
# --------------------------------------------------
def speak_text(text):
    filename = f"response_{uuid.uuid4().hex}.mp3"
    audio_path = os.path.join("static", filename)

    audio = eleven_client.text_to_speech.convert(
        voice_id=VOICE_ID,
        model_id="eleven_monolingual_v1",
        text=text
    )

    save(audio, audio_path)
    return audio_path

# --------------------------------------------------
# OPENSCAD GENERATION
# --------------------------------------------------
@app.route("/openscad", methods=["POST"])
def openscad():
    prompt = request.form.get("prompt", "").strip()

    if not prompt:
        return jsonify({"error": "No prompt provided."})

    scad_prompt = f"""
Generate ONLY valid OpenSCAD code.
No explanations.
No markdown.
No comments.

User request:
{prompt}
"""

    try:
        response = gemini_model.generate_content(scad_prompt)
        code = response.text.strip()

        os.makedirs("scad_output", exist_ok=True)

        filename = f"model_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.scad"
        filepath = os.path.join("scad_output", filename)

        with open(filepath, "w", encoding="utf-8") as f:
            f.write(code)

        return jsonify({
            "file": filename,
            "download_url": f"/download/{filename}"
        })

    except Exception as e:
        return jsonify({"error": str(e)})

# --------------------------------------------------
# FILE DOWNLOAD (CLOUD RUN SAFE)
# --------------------------------------------------
@app.route("/download/<filename>")
def download_file(filename):
    return send_from_directory(
        directory="scad_output",
        path=filename,
        as_attachment=True
    )

# --------------------------------------------------
# RUN
# --------------------------------------------------
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
